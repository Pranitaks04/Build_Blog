from selenium import webdriver
from selenium.webdriver.common.keys import Keys
driver = webdriver.Firefox()
driver.get("http://127.0.0.1:8000/")
print(driver.title)
driver.close()